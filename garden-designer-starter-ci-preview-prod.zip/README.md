# Garden Designer with CI/CD

Этот проект содержит GitHub Actions workflow для автоматического деплоя в Vercel.

## Файл CI/CD
- `.github/workflows/deploy.yml`

## Secrets, которые нужно добавить в GitHub:
- `VERCEL_ORG_ID`
- `VERCEL_PROJECT_ID`
- `VERCEL_TOKEN`


## Vercel Configuration
- `vercel.json` уже добавлен для деплоя Next.js приложения.


## vercel.json
Файл `vercel.json` добавлен для автоматической конфигурации Next.js проекта на Vercel.

## Где найти VERCEL_ORG_ID и VERCEL_PROJECT_ID

1. Зайдите в свой проект на [Vercel](https://vercel.com).
2. Перейдите в **Settings → General**.
3. В самом низу есть раздел **Project IDs**:
   - **Project ID** → это ваш `VERCEL_PROJECT_ID`
   - **Org ID** → это ваш `VERCEL_ORG_ID`

Также вы можете открыть локальный файл `.vercel/project.json` (он создаётся при `vercel link`).

Пример `.vercel/project.json`:
```json
{
  "orgId": "team_abc123xyz",
  "projectId": "prj_456def789ghi"
}
```

### GitHub Secrets
В настройках репозитория GitHub → **Settings → Secrets → Actions** добавьте:
- `VERCEL_ORG_ID = team_abc123xyz`
- `VERCEL_PROJECT_ID = prj_456def789ghi`
- `VERCEL_TOKEN = <ваш токен>`


## Пример .vercel/project.json
Файл-шаблон `.vercel/project.json` добавлен в проект:
```json
{
  "orgId": "team_abc123xyz",
  "projectId": "prj_456def789ghi"
}
```


## CI/CD с Preview и Production
- Любые ветки `feature/*` или `dev` → деплой в **Preview** (уникальная ссылка).
- Ветка `main` → деплой в **Production** (основной сайт).
